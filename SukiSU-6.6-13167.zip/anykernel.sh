block=boot
is_slot_device=auto
ramdisk_compression=auto
patch_vbmeta_flag=auto
. tools/ak3-core.sh
split_boot
flash_boot
