#!/system/bin/sh

export TMP_PATH=/data/adb/rezygisk

rm -rf $TMP_PATH
