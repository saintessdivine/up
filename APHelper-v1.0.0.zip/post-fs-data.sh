#!/system/bin/sh
# shellcheck disable=SC2034
MODDIR=${0%/*}

cd "$MODDIR" || exit

if [ ! -x "$MODDIR/aphd" ]; then
    echo "Executable $MODDIR/aphd not found or not executable"
    exit 1
fi

"$MODDIR/aphd" "$@" &