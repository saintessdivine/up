# shellcheck disable=SC2034
SKIPUNZIP=1

SUPPORTED_ABIS="arm64"

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
DESCRIPTION=$(grep_prop description "${TMPDIR}/module.prop")
ui_print "- Installing APHelper $VERSION"

# check architecture
support=false
for abi in $SUPPORTED_ABIS
do
  if [ "$ARCH" == "$abi" ]; then
    support=true
  fi
done
if [ "$support" == "false" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort    "*********************************************************"
fi
. "$TMPDIR/verify.sh"
extract "$ZIPFILE" 'customize.sh'  "$TMPDIR/.vunzip"
extract "$ZIPFILE" 'verify.sh'     "$TMPDIR/.vunzip"
export ZIPFILE

ui_print "- Extracting module files"
extract "$ZIPFILE" 'module.prop'     "$MODPATH"
extract "$ZIPFILE" 'post-fs-data.sh' "$MODPATH"

ui_print "- Extracting $ARCH libraries"
extract "$ZIPFILE" "aph.$ARCH"       "$MODPATH" true
mv "$MODPATH/aph.$ARCH" "$MODPATH/aphd"
chmod +x "$MODPATH/aphd"

ui_print "- ${DESCRIPTION}"
